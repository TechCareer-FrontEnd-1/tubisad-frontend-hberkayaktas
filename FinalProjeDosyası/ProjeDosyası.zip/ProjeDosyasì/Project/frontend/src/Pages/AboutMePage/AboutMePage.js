import React from 'react'
import AboutMe from '../../Components/AboutMe/AboutMe';
function AboutBePage() {
  return (
    <>
    <AboutMe/>
    </>
  )
}

export default AboutBePage